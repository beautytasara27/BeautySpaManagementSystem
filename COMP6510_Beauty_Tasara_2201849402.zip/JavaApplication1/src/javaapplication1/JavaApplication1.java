package javaapplication1;
import databaseconnection.ConnectToDatabase;
import frontend.WelcomeFrontEnd;

/**
 *
 * @author beauty
 */
public class JavaApplication1 {
   
  
    public static void main(String[] args) {
       ConnectToDatabase connectToDatabase = new ConnectToDatabase();
       connectToDatabase.getConn();
    WelcomeFrontEnd welcomeFrontEnd = new WelcomeFrontEnd();
   welcomeFrontEnd.setVisible(true);
 
        
       
    }
    
}
