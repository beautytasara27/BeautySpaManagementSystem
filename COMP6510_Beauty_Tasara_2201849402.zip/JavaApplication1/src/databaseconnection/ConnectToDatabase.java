package databaseconnection;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 * @author beauty
 */
public class ConnectToDatabase {
   public static Connection connecto= null;
   public static String currentUser= null;
    public ConnectToDatabase() {
     
    }


    public Connection getConn() {
    
        try {   
           Class.forName("org.apache.derby.jdbc.ClientDriver");
             connecto = DriverManager.getConnection ("jdbc:derby://localhost:1527/my_spa", "root","247365");
            System.out.println("Database connected");
            return connecto;
        } catch (Exception e) {
            return null;
        }

    }


}
