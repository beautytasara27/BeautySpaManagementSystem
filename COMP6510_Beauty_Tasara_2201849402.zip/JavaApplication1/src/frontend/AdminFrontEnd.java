/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frontend;

import static databaseconnection.ConnectToDatabase.connecto;
import static databaseconnection.ConnectToDatabase.currentUser;
import domain.CreateUserAccountRequest;
import domain.CustomerRequests;
import domain.CustomerService;
import domain.UserAccount;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author beauty
 */
public class AdminFrontEnd extends javax.swing.JFrame {

    private List<UserAccount> accountsList;
    private List<CustomerRequests> customerRequestes;
    private CustomerRequests customerRequestsService;
    private UserAccount userAccountService;

    /**
     * Creates new form AdminFrontEnd
     */
    public AdminFrontEnd() {
        initComponents();
        loadCustomerOfRequests();
        loadUserAcoounts();
     System.out.println(currentUser);
    }

    public AdminFrontEnd(CustomerRequests customerRequestsService, UserAccount userAccountService) {

        initComponents();
        loadCustomerOfRequests();
        this.userAccountService = userAccountService;
        this.customerRequestsService = customerRequestsService;

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        addCustomerServiceBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        customerRequestsView = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        viewCustomers = new javax.swing.JTable();
        back_button = new javax.swing.JButton();
        Delete_cust = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("User :");

        jLabel2.setText("Customer Requests");

        addCustomerServiceBtn.setText("Add Customer Services");
        addCustomerServiceBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCustomerServiceBtnActionPerformed(evt);
            }
        });

        jLabel3.setText("Customers Infomation");

        customerRequestsView.setAutoCreateRowSorter(true);
        customerRequestsView.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "Index", "Customer name", "Appointment date", "Service type", "Confirmed"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        customerRequestsView.setInheritsPopupMenu(true);
        customerRequestsView.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                customerRequestsViewMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(customerRequestsView);

        viewCustomers.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "UserName", "FirstName", "LastName"
            }
        ));
        jScrollPane1.setViewportView(viewCustomers);

        back_button.setText("Back");
        back_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_buttonActionPerformed(evt);
            }
        });

        Delete_cust.setText("Delete Customer Services");
        Delete_cust.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_custActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(back_button)
                        .addGap(249, 249, 249)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(addCustomerServiceBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(Delete_cust, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 529, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(68, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(173, 173, 173))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(back_button))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(143, 143, 143)
                                .addComponent(addCustomerServiceBtn)
                                .addGap(97, 97, 97)
                                .addComponent(Delete_cust))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(127, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addCustomerServiceBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCustomerServiceBtnActionPerformed

      AddCustomerServices addCustomerServices = new AddCustomerServices();
      addCustomerServices.setVisible(true);

    }//GEN-LAST:event_addCustomerServiceBtnActionPerformed

    private void back_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_buttonActionPerformed
        // TODO add your handling code here:
        this.hide();
        WelcomeFrontEnd welc = new WelcomeFrontEnd();
        welc.setVisible(true);
    }//GEN-LAST:event_back_buttonActionPerformed

    private void Delete_custActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_custActionPerformed
        DeleteService del= new DeleteService();
        del.setVisible(true);
    }//GEN-LAST:event_Delete_custActionPerformed

    private void customerRequestsViewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_customerRequestsViewMouseClicked
        DefaultTableModel model1 =(DefaultTableModel)customerRequestsView.getModel();
        int selectedRowIndex = customerRequestsView.getSelectedRow();
        System.out.println(selectedRowIndex);
        Object columnValue = customerRequestsView.getValueAt(selectedRowIndex ,0);
        System.out.println(columnValue);
        try{
            String sql = "UPDATE CUSTOMERREQUESTS SET CONFIRMED = (TRUE) WHERE ID ='"+columnValue+"'";
            PreparedStatement pstmt = connecto.prepareStatement(sql);
            //pstmt.setBoolean(selectedRowIndex, true);
            int i = pstmt.executeUpdate();
            if (i == 1) {
                connecto.commit();
                return;
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_customerRequestsViewMouseClicked

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                new AdminFrontEnd().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Delete_cust;
    private javax.swing.JButton addCustomerServiceBtn;
    private javax.swing.JButton back_button;
    private javax.swing.JTable customerRequestsView;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable viewCustomers;
    // End of variables declaration//GEN-END:variables

    private void loadCustomerOfRequests() {
        System.out.println("hello");
        DefaultTableModel model = (DefaultTableModel) customerRequestsView.getModel();
        customerRequestes = customerRequestsService.getAllCustomerRequests();
        System.out.println(customerRequestes);
        Object rowData[] = new Object[4];
        for (int i = 0; i < customerRequestes.size(); i++) {
            rowData[0] = customerRequestes.get(i).getId();
            rowData[1] = customerRequestes.get(i).getCustomerName();
            rowData[2] = customerRequestes.get(i).getServiceDate();
            rowData[3] = customerRequestes.get(i).getCustomerService();
            model.addRow(rowData);
        }
    }

    private void loadUserAcoounts() {
        DefaultTableModel model = (DefaultTableModel) viewCustomers.getModel();
        accountsList = UserAccount.getAllUserAccounts();
        Object rowData[] = new Object[4];
        for (int i = 0; i < accountsList.size(); i++) {
            rowData[0] = accountsList.get(i).getUsername();
            rowData[1] = accountsList.get(i).getFirstName();
            rowData[2] = accountsList.get(i).getLastName();
            model.addRow(rowData);
        }
    }
}
