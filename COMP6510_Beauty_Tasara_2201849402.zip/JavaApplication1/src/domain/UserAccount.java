package domain;

import static databaseconnection.ConnectToDatabase.connecto;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.activity.InvalidActivityException;
import javax.swing.JOptionPane;

/**
 * @author beauty
 */
public class UserAccount implements Serializable {

    private int id;

    private String username;

    private String password;

    private boolean admin;

    private String firstName;

    private String lastName;

    private String email;
    
    

    public UserAccount() {

    }

    protected UserAccount(boolean admin) {
        this.admin = admin;
    }

    public UserAccount(String username, String password, boolean admin, String firstName, String lastName, String email) {
        this.username = username;
        this.password = password;
        this.admin = admin;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

   

    public static boolean createUserAccount(CreateUserAccountRequest createUserAccountRequest) {
        if (confirmPassword(createUserAccountRequest)) {
            UserAccount userAccount = new UserAccount(createUserAccountRequest.getUsername(), createUserAccountRequest.getPassword(), createUserAccountRequest.isIsAdmin(), createUserAccountRequest.getFirstName(),createUserAccountRequest.getLastName(), createUserAccountRequest.getEmail());
            return saveUserAccount(userAccount);
        };

        return false;
    }

    public static boolean saveUserAccount(UserAccount userAccount) {

        try {
            String sql = "INSERT INTO USERACCOUNT(id,username,password,firstname,lastname,isadmin,email) VALUES(?,?,?,?,?,?,?)";
            PreparedStatement pstmt = connecto.prepareStatement(sql);
            pstmt.setInt(1, new Random().nextInt(10000));
            pstmt.setString(2, userAccount.getUsername());
            pstmt.setString(3, userAccount.getPassword());
            pstmt.setString(4, userAccount.getFirstName());
            pstmt.setString(5, userAccount.getLastName());
            pstmt.setBoolean(6, userAccount.isAdmin());
            pstmt.setString(7, userAccount.getEmail());
            int i = pstmt.executeUpdate();
            if (i == 1) {
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static List<UserAccount> getAllUserAccounts() {

        try {
            String sql = "SELECT * FROM  USERACCOUNT";
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
             List<UserAccount> userAccountsList = new ArrayList<UserAccount>();
            while (resultSet.next()) {
                Integer id = resultSet.getInt("ID");
                String username = resultSet.getString("USERNAME");
                String email = resultSet.getString("EMAIL");
                String password = resultSet.getString("PASSWORD");
                String firstname = resultSet.getString("FIRSTNAME");
                String lastname = resultSet.getString("LASTNAME");
                boolean isAdmin = resultSet.getBoolean("ISADMIN");
                UserAccount account = new UserAccount();
                account.setId(id);
                account.setUsername(username);
                account.setAdmin(isAdmin);
                account.setFirstName(firstname);
                account.setLastName(lastname);
                account.setPassword(password);
                account.setEmail(email);
               userAccountsList.add(account);
            }
            return userAccountsList;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public static UserAccount getUserAccountByUserName(String query) {

        try {
            String sql = "SELECT * FROM USERACCOUNT WHERE USERNAME='"+query+"'" ;
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Integer id = resultSet.getInt("ID");
                String username = resultSet.getString("USERNAME");
                String email = resultSet.getString("EMAIL");
                String password = resultSet.getString("PASSWORD");
                String firstname = resultSet.getString("FIRSTNAME");
                String lastname = resultSet.getString("LASTNAME");
                boolean isAdmin = resultSet.getBoolean("ISADMIN");
                UserAccount account = new UserAccount();
                account.setId(id);
                account.setUsername(username);
                account.setAdmin(isAdmin);
                account.setFirstName(firstname);
                account.setLastName(lastname);
                account.setPassword(password);
                account.setEmail(email);
                System.out.println(account);
                return account;

            }
        } 
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
     
    }

    static boolean confirmPassword(CreateUserAccountRequest createUserAccountRequest) {
        if (createUserAccountRequest.getConfirmPassword().equals(createUserAccountRequest.getPassword())) {
            return true;
        }
        else{return false;}
        
    }
    
    public static boolean checkDuplicateUsername(String username) {
     UserAccount account= getUserAccountByUserName(username);
     if(account!=null){
     return true;
     }
     return false;
     }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    @Override
    public String toString() {
        return "UserAccount{" + "id=" + id + ", username=" + username + ", password=" + password + ", admin=" + admin + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + '}';
    }

}
