package domain;

import static databaseconnection.ConnectToDatabase.connecto;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * @author beauty
 */
public class CustomerRequests {
    private int id;
    private Date serviceDate;
    private String customerService;
    private String customerName;
    private static Boolean confirmed;

    public CustomerRequests(Date serviceDate, String customerService, String customerName, Boolean confirmed) {
        this.serviceDate = serviceDate;
        this.customerService = customerService;
        this.customerName = customerName;
        this.confirmed = confirmed;
    }

    public CustomerRequests(int id, Date serviceDate, String customerService, String customerName,Boolean confirmed) {
        this.id = id;
        this.serviceDate = serviceDate;
        this.customerService = customerService;
        this.customerName = customerName;
        this.confirmed = confirmed;
    }

    public static CustomerRequests createCustomerRequests(Date serviceDate, String customerService, String customerName) {
        CustomerRequests customerRequests = new CustomerRequests(serviceDate, customerService, customerName, confirmed);
        saveCustomerRequests(customerRequests);
        return customerRequests;
    }

    public static boolean saveCustomerRequests(CustomerRequests customerRequests) {

        try {
            String sql = "INSERT INTO customerRequests(id,servicedate,customerservice,customername) VALUES(?,?,?,?)";
            PreparedStatement pstmt = connecto.prepareStatement(sql);
            pstmt.setInt(1, new Random().nextInt(10000));
            java.util.Date utilDate = customerRequests.getServiceDate();
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
            pstmt.setDate(2, sqlDate);
            pstmt.setString(3, customerRequests.getCustomerService());
            pstmt.setString(4, customerRequests.getCustomerName());
            int i = pstmt.executeUpdate();
            if (i == 1) {
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static List<CustomerRequests> getAllCustomerRequests()  {

        try {
            String sql = "SELECT * FROM  CUSTOMERREQUESTS";
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<CustomerRequests> customerRequestsList = new ArrayList<CustomerRequests>();
             
            while (resultSet.next()) {
                Integer id = resultSet.getInt("ID");
                Date serviceDate = resultSet.getDate("SERVICEDATE");
                String customerService = resultSet.getString("CUSTOMERSERVICE");
                String customerName = resultSet.getString("CUSTOMERNAME");
                DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);
                Boolean confirm = resultSet.getBoolean("CONFIRMED");
                CustomerRequests customerRequests = new CustomerRequests(id, serviceDate, customerService, customerName, confirm);
                customerRequestsList.add(customerRequests);
            }
            return customerRequestsList;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public static List<CustomerRequests> getCustomerRequestsByCustomername(String query) {

        try {
            String sql = "SELECT * FROM CUSTOMERREQUESTS WHERE CUSTOMERNAME='" + query + "'";
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<CustomerRequests> customerRequestsList = new ArrayList<CustomerRequests>();
            while (resultSet.next()) {
                Integer id = resultSet.getInt("ID");
                Date serviceDate = resultSet.getDate("SERVICEDATE");
                String customerService = resultSet.getString("CUSTOMERSERVICE");
                System.out.println("cust erv = "+ customerService);
                String customerName = resultSet.getString("CUSTOMERNAME");
                Boolean confirm = resultSet.getBoolean("CONFIRMED");
                CustomerRequests customerRequests = new CustomerRequests(id, serviceDate, customerService, customerName,confirm);
                customerRequestsList.add(customerRequests);

            }
            return customerRequestsList;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public Date getServiceDate() {
        return serviceDate;
    }

    public void setServiceDate(Date serviceDate) {
        this.serviceDate = serviceDate;
    }

    public String getCustomerService() {
        return customerService;
    }

    public void setCustomerService(String customerService) {
        this.customerService = customerService;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    
    public void setConfirmed(Boolean confirmed){
        this.confirmed = confirmed;
    }
    public Boolean getConfirmed(){
        return confirmed;
    }

    @Override
    public String toString() {
        return "CustomerRequests{" + "id=" + id + ", serviceDate=" + serviceDate + ", customerService=" + customerService + ", customerName=" + customerName + '}';
    }
    
    
}
