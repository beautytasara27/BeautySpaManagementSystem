/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import static databaseconnection.ConnectToDatabase.connecto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author beauty
 */
public class CustomerService {
    private int id;
    private String name;
    private double amount;

    public CustomerService(int id,String name, double amount) {
        this.id=id;
        this.name = name;
        this.amount = amount;
    }

    public CustomerService(String name, double amount) {
        this.name = name;
        this.amount = amount;
    }

    
    public CustomerService() {
    }
     
    
    public static CustomerService createCustomerService(String name, double amount) {
      CustomerService customerService= new  CustomerService(name,amount);
       saveCustomerService(customerService);
       return customerService;
    }
        public static boolean saveCustomerService(CustomerService customerService) {
        try {
            String sql = "INSERT INTO CUSTOMERSERVICE(id,name,amount) VALUES(?,?,?)";
            PreparedStatement pstmt = connecto.prepareStatement(sql);
            pstmt.setInt(1, new Random().nextInt(10000));
            pstmt.setString(2, customerService.getName());
            pstmt.setDouble(3, customerService.getAmount());
         
            int i = pstmt.executeUpdate();
            if (i == 1) {
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }
        
    public static CustomerService getCustomerService(String query) {

        try {
            String sql = "SELECT * FROM CUSTOMERSERVICE WHERE NAME='"+query+"'" ;
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Integer id = resultSet.getInt("ID");
                String name = resultSet.getString("NAME");
                 double amount = resultSet.getDouble("AMOUNT");
                return new CustomerService(id,name,amount);
            }
        } 
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
     
    }
    
       public static  List<CustomerService> getAllCustomerService() {

        try {
            String sql = "SELECT * FROM CUSTOMERSERVICE " ;
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
             
              List<CustomerService> customerServicesList= new ArrayList<CustomerService>();
             
            while (resultSet.next()) {
                
                Integer id = resultSet.getInt("ID");
                String name = resultSet.getString("NAME");
                double amount = resultSet.getDouble("AMOUNT");
                CustomerService customerService=new CustomerService(id,name,amount);
                customerServicesList.add(customerService) ;
                 
            }
            return customerServicesList;
        } 
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
     
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "CustomerService{" + "id=" + id + ", name=" + name + ", amount=" + amount + '}';
    }

 
    
    
    
}
